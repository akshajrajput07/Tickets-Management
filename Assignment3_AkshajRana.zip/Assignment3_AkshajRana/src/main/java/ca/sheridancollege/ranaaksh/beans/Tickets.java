package ca.sheridancollege.ranaaksh.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Tickets {
	
	private int Id;
	
	private String name;
	private double price;
	private String email;
	private String phNumber;
	private String support;
	private String payment;
	

}
