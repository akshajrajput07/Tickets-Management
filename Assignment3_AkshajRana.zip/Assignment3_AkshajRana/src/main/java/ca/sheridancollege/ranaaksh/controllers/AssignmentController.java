package ca.sheridancollege.ranaaksh.controllers;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import ca.sheridancollege.ranaaksh.beans.Tickets;
import ca.sheridancollege.ranaaksh.repositories.TicketRepository;
import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
public class AssignmentController {
	
	private TicketRepository ticRepo;
	
	@GetMapping("/")
	public String home() {
	return "root.html";
	}
	
	@GetMapping("/add")
	public String add(Model model) {
		model.addAttribute("tickets", new Tickets());
		return "Add.html";
	}
	
	@PostMapping("/add")
	public String processAdd( @ModelAttribute Tickets tickets) {
		ticRepo.addTickets(tickets);
		return "redirect:/add";    
		}
	
	@GetMapping("/view")
	public String viewpage(Model model) {
		ArrayList<Tickets> tickets = ticRepo.getTickets();
		model.addAttribute("tickets",tickets);
		return "View.html";
	}
	
	@GetMapping("/edit/{id}")
	public String editDrink(Model model,@PathVariable int id) {
		
		Tickets tickets = ticRepo.getDrinkById(id);
		
		model.addAttribute("tickets",tickets);
		
		return"edit.html";
	}
	
	@PostMapping("/edit")
	public String editprocessEdit(Model model,@ModelAttribute Tickets tickets) {
		

		ticRepo.editTickets(tickets);
		
		return"redirect:/view";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteDrink(Model model,@PathVariable int id) {
	ticRepo.deleteTicketById(id);
	return "redirect:/view";
	}


}
