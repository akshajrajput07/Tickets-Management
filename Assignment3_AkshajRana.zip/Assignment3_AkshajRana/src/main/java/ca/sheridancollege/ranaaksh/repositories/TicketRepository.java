package ca.sheridancollege.ranaaksh.repositories;

import java.util.ArrayList;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.ranaaksh.beans.Tickets;
import lombok.AllArgsConstructor;

@Repository
@AllArgsConstructor
public class TicketRepository {
	
	private NamedParameterJdbcTemplate jdbc;
	
	public void addTickets(Tickets tickets) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String query = "INSERT INTO tickets(name, price, email, phNumber, support, payment) VALUES"
		        + "(:na, :pr, :em, :ph, :su, :pa)";
		parameters.addValue("na", tickets.getName());
		parameters.addValue("pr", tickets.getPrice());
		parameters.addValue("em", tickets.getEmail());
		parameters.addValue("ph", tickets.getPhNumber());
		parameters.addValue("su", tickets.getSupport());
		parameters.addValue("pa", tickets.getPayment());
		jdbc.update(query, parameters);
	}
	
	public ArrayList<Tickets> getTickets()
	{
		   
		   MapSqlParameterSource parameters = new MapSqlParameterSource();
		   String query = "SELECT * FROM tickets";
		   ArrayList<Tickets>ticket = (ArrayList<Tickets>) jdbc.query(query, parameters,
				                     new BeanPropertyRowMapper<Tickets>(Tickets.class));	   
	    return ticket;
	}
	
public Tickets getDrinkById(int id) {
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String query = "SELECT * FROM tickets WHERE id=:meow";
		parameters.addValue("meow", id);
		ArrayList<Tickets> tickets= (ArrayList<Tickets>) jdbc.query(query, parameters, new BeanPropertyRowMapper<Tickets>(Tickets.class));
		
		if(tickets.size()>0)
			return tickets.get(0);
		else
		return null;
		
		
	}

public void editTickets(Tickets tickets) {
	
	MapSqlParameterSource parameters = new MapSqlParameterSource();
	String query = "UPDATE tickets SET"
            +" name=:na, price=:pr, email=:em,phNumber=:ph,"
	          +" support=:su, payment=:pa WHERE id=:meow";
	parameters.addValue("meow", tickets.getId());
	parameters.addValue("na", tickets.getName());
	parameters.addValue("m1", tickets.getPrice());
	parameters.addValue("a1", tickets.getEmail());
	parameters.addValue("m2", tickets.getPhNumber());
	parameters.addValue("a2", tickets.getSupport());
	parameters.addValue("dir", tickets.getPayment());
	jdbc.update(query, parameters);
			
}	

public void deleteTicketById(int id) {
	MapSqlParameterSource parameters=new MapSqlParameterSource();
	String query = "DELETE  FROM tickets WHERE id=:meow";
	parameters.addValue("meow", id);
	

	jdbc.update(query, parameters);
	
}


}



