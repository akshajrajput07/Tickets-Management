package ca.sheridancollege.ranaaksh.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.ranaaksh.beans.User;
import lombok.AllArgsConstructor;
@AllArgsConstructor
@Repository
public class SecRepository
{
private NamedParameterJdbcTemplate jdbc;
	
	public User findUserByUsername(String username) {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			String query = "SELECT * FROM SEC_USER WHERE userName=:un";
			parameters.addValue("un",username);
			
			ArrayList<User> user = 
					(ArrayList<User>) jdbc.query(query, parameters,
			new BeanPropertyRowMapper<User>(User.class));
			if(user.size()>0)
				return user.get(0);
			return null;
}
	public ArrayList<String> getRolesById(long userId) {
		ArrayList<String> roles = new ArrayList<String>();
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String query = "SELECT user_role.userId, sec_role.roleName "
				+ "FROM user_role, sec_role "
				+ "WHERE user_role.roleId=sec_role.roleId "
				+ "AND userId=:id";
		parameters.addValue("id", userId);
		List<Map<String, Object>> rows =
				jdbc.queryForList(query, parameters);
		for(Map<String, Object> row : rows) {
			roles.add((String)row.get("roleName"));
		}
		return roles;
	}
	public void register(String username,String password )
	{
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String encodePassword = encoder.encode(password);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String query = "Insert into SEC_User"+"(userName,encryptedPassword,ENABLED)"+"values(:un ,:pa, 1)";
		parameters.addValue("un",username);
		parameters.addValue("pa",encodePassword);
		jdbc.update(query,parameters);
	}
}
	
	

