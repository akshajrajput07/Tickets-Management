package ca.sheridancollege.ranaaksh.securities;
import static org. springframework. security. web.util.matcher.AntPathRequestMatcher.antMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;

import lombok.AllArgsConstructor;
@Configuration
@EnableWebSecurity
@AllArgsConstructor
public class SecurityConfig
{   
	@Autowired
        private AccessDeniedHandler accessDenied;
	    
	    private UserDetailsServiceImpl userDetailsService;
		@Bean
		public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
		}
		@Bean
		public AuthenticationManager authManager(HttpSecurity http,
		PasswordEncoder passwordEncoder) throws Exception {
		AuthenticationManagerBuilder authenticationManagerBuilder =
		http.getSharedObject(AuthenticationManagerBuilder.class);
		authenticationManagerBuilder.userDetailsService(userDetailsService)
		.passwordEncoder(passwordEncoder);
		return authenticationManagerBuilder.build();
		}

		
		 
		@Bean
		public SecurityFilterChain filterChain(HttpSecurity http) throws Exception
		{
		
		http.authorizeHttpRequests((authz) -> authz
		.requestMatchers(antMatcher("/vendor")).hasRole("VENDOR")
		.requestMatchers(antMatcher("/user")).hasRole("USER")
		.requestMatchers(antMatcher("/view")).hasAnyRole("VENDOR","GUEST")
		.requestMatchers(antMatcher("/edit")).hasAnyRole("VENDOR","GUEST")
		//permitAll->Can access without logging in
		//hasRole("ROLE") for a specific role
		//hasAnyRole("ROLE1", "ROLE2") for more roles
		
		.requestMatchers(antMatcher("/register")).permitAll()
		.requestMatchers(antMatcher(HttpMethod.POST,"/register")).permitAll()
		.requestMatchers(antMatcher("/add")).permitAll()
		
		.requestMatchers(antMatcher("/img/**")).permitAll()
		.anyRequest().authenticated()
		)
		
			.formLogin((formLogin) -> formLogin
					.loginPage("/login")
					.failureUrl("/login?failed")
					.permitAll()
		    )
			.logout((logout) -> logout
					.deleteCookies("remove")
					.invalidateHttpSession(false)
					.logoutUrl("/logout")
					.logoutSuccessUrl("/?logout")
					.permitAll()
			)
			.exceptionHandling((exceptionHandling) ->exceptionHandling
					.accessDeniedHandler(accessDenied)
			
			);
			return http.build();
		}
	}