INSERT INTO tickets(name, price, email, phNumber, support, payment) VALUES 
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' ),
('Akshaj', 300.0,'a@a.ca', '2354326743', 'India', 'Debit' );

insert into SEC_USER (userName, encryptedPassword, ENABLED)
values ('jon', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', 1);
 
insert into SEC_USER (userName, encryptedPassword, ENABLED)
values ('hola', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', 1);

/*insert into User (userName, encryptedPassword, ENABLED)
values ('ok', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', 1);

insert into User (userName, encryptedPassword, ENABLED)
values ('hi', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', 1);

insert into User (userName, encryptedPassword, ENABLED)
values ('meow', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', 1);

insert into User (userName, encryptedPassword, ENABLED)
values ('woof', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', 1);
 */
insert into sec_role (roleName)
values ('ROLE_VENDOR');
 
insert into sec_role (roleName)
values ('ROLE_GUEST');


 
insert into user_role (userId, roleId)
values (1, 1);
 
insert into user_role (userId, roleId)
values (2, 2);

/*insert into user_role (userId, roleId)
values (3, 2);

insert into user_role (userId, roleId)
values (4, 2);

insert into user_role (userId, roleId)
values (5, 2);

insert into user_role (userId, roleId)
values (6, 2);*/
